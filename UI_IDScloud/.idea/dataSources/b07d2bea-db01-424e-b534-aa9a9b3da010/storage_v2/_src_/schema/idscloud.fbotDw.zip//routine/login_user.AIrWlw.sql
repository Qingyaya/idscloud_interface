CREATE PROCEDURE login_user()
  BEGIN
	#Routine body goes here...


DECLARE i INT DEFAULT 11;


WHILE i<50000
DO 
insert into tb_login_user(user_name,password,account_type,usr_id) values(CONCAT('test',cast(i as char)),'e10adc3949ba59abbe56e057f20f883e',3,cast(i as char));
SET i=i+1; 
END WHILE ; 
commit; 



END;

