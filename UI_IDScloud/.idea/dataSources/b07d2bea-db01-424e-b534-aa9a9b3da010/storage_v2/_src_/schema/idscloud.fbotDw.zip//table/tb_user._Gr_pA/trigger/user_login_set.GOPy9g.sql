CREATE TRIGGER user_login_set
  AFTER INSERT
  ON tb_user
  FOR EACH ROW
  BEGIN   
  INSERT INTO tb_login_user 
	SET user_name=NEW.login_name,password=NEW.password,
  account_type=2,usr_id=NEW.usr_id;
 INSERT INTO tb_login_user 
	SET user_name=NEW.mobile,password=NEW.password,
  account_type=3,usr_id=NEW.usr_id;
IF NEW.mail !="" THEN
  INSERT INTO tb_login_user 
	SET user_name=NEW.mail,password=NEW.password,
  account_type=4,usr_id=NEW.usr_id;
end if;
END;

