CREATE FUNCTION queryUpSorgIds(areaId VARCHAR(50))
  RETURNS VARCHAR(4000)
  BEGIN

DECLARE sTemp VARCHAR (4000);


DECLARE sTempChd VARCHAR (4000);


SET sTemp = '$';


SET sTempChd = areaId;


SET sTemp = CONCAT(sTemp, ',', sTempChd);

SELECT
	SORG_PARENT_ID INTO sTempChd
FROM
	sorg
WHERE
	sorg_id = sTempChd;


WHILE sTempChd <> '0' DO

SET sTemp = CONCAT(sTemp, ',', sTempChd);

SELECT
	SORG_PARENT_ID INTO sTempChd
FROM
	sorg
WHERE
	sorg_id = sTempChd;


END
WHILE;

RETURN sTemp;


END;

