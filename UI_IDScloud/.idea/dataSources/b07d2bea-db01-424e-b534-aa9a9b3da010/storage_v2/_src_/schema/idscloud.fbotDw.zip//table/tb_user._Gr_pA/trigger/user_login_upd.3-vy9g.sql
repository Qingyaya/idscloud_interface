CREATE TRIGGER user_login_upd
  AFTER UPDATE
  ON tb_user
  FOR EACH ROW
  BEGIN   
     delete from tb_login_user 
	where usr_id=old.usr_id;
     INSERT INTO tb_login_user 
	SET user_name=NEW.login_name,password=NEW.password,
  account_type=2,usr_id=NEW.usr_id;
 INSERT INTO tb_login_user 
	SET user_name=NEW.mobile,password=NEW.password,
  account_type=3,usr_id=NEW.usr_id;
IF NEW.mail !=null THEN
  INSERT INTO tb_login_user 
	SET user_name=NEW.mail,password=NEW.password,
  account_type=4,usr_id=NEW.usr_id;
end if;
 END;

