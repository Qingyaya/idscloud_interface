CREATE FUNCTION queryDownSorgIds(areaId VARCHAR(50))
  RETURNS VARCHAR(4000)
  BEGIN

DECLARE sTemp VARCHAR (4000);


DECLARE sTempChd VARCHAR (4000);


SET sTemp = '$';


SET sTempChd = areaId;


WHILE sTempChd IS NOT NULL DO

SET sTemp = CONCAT(sTemp, ',', sTempChd);

SELECT
	GROUP_CONCAT(sorg_id) INTO sTempChd
FROM
	sorg
WHERE
	FIND_IN_SET(SORG_PARENT_ID, sTempChd) > 0;


END
WHILE;

RETURN sTemp;


END;

