CREATE TRIGGER user_login_del
  AFTER DELETE
  ON tb_user
  FOR EACH ROW
  BEGIN   
  delete from tb_login_user 
	where usr_id=old.usr_id;
END;

